# _Portfolio Project - End of Week One_

#### _Practice Git operations, HTML, CSS and Bootstrap 4 Oct 13th 2017_

#### By _**Chris Quattrocchi**_

## Description

_End of week one recap. Covers skills learned in HTML, CSS and Bootstrap, as well as best practices using Git and the Terminal. I don't have access to my resume, and current pictures, or anything like that, so I used images I found and provided space filler text to demonstrate what it will look like when fully fleshed out._

## Setup/Installation Requirements

* _clone repository_
* _enjoy_
* _git is required_


## Known Bugs

_I'm sure you could break this if you really wanted to._

## Support and contact details

_chrisquattrocchi@gmail.com, phone number is 503-841-0072_

## Technologies Used

_HTML, CSS, Git and a Google Font were used in the creation of this site. Git and Github used to store/update as necessary_

### License

Copyright (c) 2017-3077 **_{Chris Quattrocchi}_**
